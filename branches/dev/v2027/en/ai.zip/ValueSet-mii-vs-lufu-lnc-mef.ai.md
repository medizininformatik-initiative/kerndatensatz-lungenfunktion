# MII VS Lufu LNC MEF - MII IG Kerndatensatz-Modul Lungenfunktion v2027.0.0-ballot.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MII VS Lufu LNC MEF**

## ValueSet: MII VS Lufu LNC MEF 

| | |
| :--- | :--- |
| *Official URL*:https://www.medizininformatik-initiative.de/fhir/modul-lungenfunktion/ValueSet/mii-vs-lufu-lnc-mef | *Version*:2027.0.0-ballot.1 |
| Active as of 2026-09-15 | *Computable Name*:MII_VS_Lufu_LNC_MEF |
| **Copyright/Legal**: This material contains content from LOINC (http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the license at http://loinc.org/license. LOINC® is a registered United States trademark of Regenstrief Institute, Inc) | |

 
Import the ValueSet for lungfunction maximum expiratory flow 

 **References** 

* [MII PR Lungenfunktion MEF](StructureDefinition-mii-pr-lungenfunktion-mef.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-lufu-lnc-mef",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/StructureDefinition/shareablevalueset"]
  },
  "url" : "https://www.medizininformatik-initiative.de/fhir/modul-lungenfunktion/ValueSet/mii-vs-lufu-lnc-mef",
  "version" : "2027.0.0-ballot.1",
  "name" : "MII_VS_Lufu_LNC_MEF",
  "title" : "MII VS Lufu LNC MEF",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-09-15",
  "publisher" : "Medizininformatik Initiative",
  "contact" : [{
    "name" : "Medizininformatik Initiative",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/"
    }]
  }],
  "description" : "Import the ValueSet for lungfunction maximum expiratory flow",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "copyright" : "This material contains content from LOINC (http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the license at http://loinc.org/license. LOINC® is a registered United States trademark of Regenstrief Institute, Inc)",
  "compose" : {
    "include" : [{
      "system" : "http://loinc.org",
      "concept" : [{
        "code" : "65821-1",
        "display" : "Gas flow FEV 25%"
      },
      {
        "code" : "65822-9",
        "display" : "Gas flow FEV 50%"
      },
      {
        "code" : "65823-7",
        "display" : "Gas flow FEV 75%"
      },
      {
        "code" : "65824-5",
        "display" : "Gas flow FEV 90%"
      },
      {
        "code" : "69972-8",
        "display" : "FEF 25-75% --pre bronchodilation"
      },
      {
        "code" : "69973-6",
        "display" : "FEF 25-75% --post bronchodilation"
      },
      {
        "code" : "69971-0",
        "display" : "FEF 25-75% Predicted"
      },
      {
        "code" : "19927-3",
        "display" : "Gas flow FEV 25%-75%"
      },
      {
        "code" : "19945-5",
        "display" : "Gas flow FEV 25%-75% airway"
      }]
    }]
  }
}

```
