# MII Example Lungenfunktion DLCOc - MII IG Kerndatensatz-Modul Lungenfunktion v2027.0.0-ballot.1

* [**Inhaltsverzeichnis**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **MII Example Lungenfunktion DLCOc**

## Beispiel Observation: MII Example Lungenfunktion DLCOc

-------

**German**

-------

Profile: [MII PR Lungenfunktion DLCOc](StructureDefinition-mii-pr-lungenfunktion-dlcoc.md)

**partOf**: [Procedure Carbon monoxide diffusing capacity measurement (procedure)](Procedure-mii-exa-lungenfunktion-diffusion-messung.md)

**status**: Final

**category**: Procedure

**code**: Diffusion capacity.carbon monoxide

**subject**: [Erika Beispielpatientin Female, DoB: 1970-01-01](Patient-mii-exa-lungenfunktion-patient.md)

**issued**: 2024-07-19 13:03:20+0200

**value**: 8.27 mmol/(min.kPa) (Details: UCUM codemmol/(min.kPa) = 'mmol/(min.kPa)')

**interpretation**: Normal

**method**: Sitting upright (finding)

### ReferenceRanges

| | |
| :--- | :--- |
| - | **Low** |
| * | 7.29 mmol/(min.kPa) (Details: UCUM codemmol/(min.kPa) = 'mmol/(min.kPa)') |

**derivedFrom**: 

* [Observation Hemoglobin [Mass/volume] in Blood](Observation-mii-exa-lungenfunktion-hb.md)
* [Observation Diffusion capacity.carbon monoxide](Observation-mii-exa-lungenfunktion-dlco.md)

> **component****code**: Diffusion capacity.carbon monoxide Predicted**value**: 9.5 mmol/(min.kPa) (Details: UCUM codemmol/(min.kPa) = 'mmol/(min.kPa)')

> **component****code**: Diffusion capacity.carbon monoxide/Predicted**value**: 87 % (Details: UCUM code% = '%')

> **component****code**: Z-score calculation technique (qualifier value)**value**: -0.9



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "mii-exa-lungenfunktion-dlcoc",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-lungenfunktion/StructureDefinition/mii-pr-lungenfunktion-dlcoc"]
  },
  "partOf" : [{
    "reference" : "Procedure/mii-exa-lungenfunktion-diffusion-messung"
  }],
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "procedure"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "19911-7",
      "display" : "Diffusion capacity.carbon monoxide"
    }]
  },
  "subject" : {
    "reference" : "Patient/mii-exa-lungenfunktion-patient"
  },
  "issued" : "2024-07-19T13:03:20+02:00",
  "valueQuantity" : {
    "value" : 8.27,
    "system" : "http://unitsofmeasure.org",
    "code" : "mmol/(min.kPa)"
  },
  "interpretation" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-ObservationInterpretation",
      "code" : "N"
    }]
  }],
  "method" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "version" : "http://snomed.info/sct/900000000000207008/version/20260701",
      "code" : "249862003",
      "display" : "Sitting upright (finding)"
    }]
  },
  "referenceRange" : [{
    "low" : {
      "value" : 7.29,
      "system" : "http://unitsofmeasure.org",
      "code" : "mmol/(min.kPa)"
    }
  }],
  "derivedFrom" : [{
    "reference" : "Observation/mii-exa-lungenfunktion-hb"
  },
  {
    "reference" : "Observation/mii-exa-lungenfunktion-dlco"
  }],
  "component" : [{
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "19910-9",
        "display" : "Diffusion capacity.carbon monoxide Predicted"
      }]
    },
    "valueQuantity" : {
      "value" : 9.5,
      "system" : "http://unitsofmeasure.org",
      "code" : "mmol/(min.kPa)"
    }
  },
  {
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "98130-8",
        "display" : "Diffusion capacity.carbon monoxide/Predicted"
      }]
    },
    "valueQuantity" : {
      "value" : 87,
      "system" : "http://unitsofmeasure.org",
      "code" : "%"
    }
  },
  {
    "code" : {
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "version" : "http://snomed.info/sct/900000000000207008/version/20260701",
        "code" : "1078210003",
        "display" : "Z-score calculation technique (qualifier value)"
      }]
    },
    "valueQuantity" : {
      "value" : -0.9,
      "system" : "http://unitsofmeasure.org"
    }
  }]
}

```
