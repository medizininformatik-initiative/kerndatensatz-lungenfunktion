<!-- Quelle: MIIIGModulLungenfunktion/TechnischeImplementierung/FHIR-Profile/Bodyplethysmographie/Observation/R_tot.page.md (Guide-Baum mii-ig-lungenfunktion-de-v2026, main@c2fe7fe); migriert 2026-08-28. Verbatim uebernommen - NICHT als DERIVED markiert. -->
<!-- Die Beispiel-Anmoderation der Quellseite entfaellt: der IG Publisher listet die Beispiele selbst auf der Artefaktseite. -->

Diese Observation beschreibt den gemessenen totalen Atemwegswiderstand.
